# AggregationWidgetService
## getWidgetUrl
    
    new AggregationRequest(requestCode: rc, user: user, uuid: uuid, sourceType: wic.sourceType).save()
## getWidgetUrlUpdate
    
    new AggregationRequest(requestCode: rc, user: ar.user, aggregationResponse: ar, uuid: uuid, sourceType: ar.institution.sourceType).save()
